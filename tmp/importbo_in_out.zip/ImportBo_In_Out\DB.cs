﻿
using System;
using System.Data;
using System.Data.SqlClient;
using BCS.Aladdin.CredentialBroker.Client;


namespace ImportBo_In_Out
{

    public class DB
    {
        public SqlConnection _connection;
        private int _commandTimeout;

        public void Database(string databaseName, int commandTimeout)
        {
            if (databaseName == null)
                throw new ArgumentNullException("databaseName");

            if (string.IsNullOrWhiteSpace(databaseName))
                throw new ArgumentException("Database name is empty.", "databaseName");

            if (commandTimeout < 0)
                throw new ArgumentException("Command timeout is less than zero.", "commandTimeout");



            using (var client = new CredentialBrokerClient(new CredentialBrokerClientOptions
            {
                BrokerUrl = "http://127.0.0.1:8731",
                TokenFilePath = @"D:\Apps\Protected\credential-broker.token",
                FallbackMode = FallbackMode.AnyFailureBySecretName
            }))
            {
                var credentials = client.GetCredentialsAsync("Aladdin")
                    .GetAwaiter().GetResult();
                var connectionString = new SqlConnectionStringBuilder
                {
                    DataSource = "localhost",
                    InitialCatalog = databaseName,
                    UserID = credentials.User,
                    Password = credentials.Password
                };

                _connection = new SqlConnection(connectionString.ConnectionString);
                _commandTimeout = commandTimeout;
            }
        }

        public void Open()
        {
            _connection.Open();

        }

        public bool IsOpened()
        {
            return (_connection.State == ConnectionState.Open);
        }

        public void Close()
        {
            _connection.Close();
        }

        public void LogErrors(int export_id, Exception Err, string Src)
        {
            if (IsOpened() == false) Open();
            string err_desc = "В пакете: " + Err.Source + " Ошибка: " + Err.Message;

            SqlCommand er_cmd = new SqlCommand();
            er_cmd.Connection = _connection;

            er_cmd.CommandText = "update bcs_bo_oper_status_list set err_desc = isnull( err_desc , '') + '" + err_desc + "'  where id = " + export_id;


            er_cmd.CommandTimeout = _commandTimeout;
            if (er_cmd.CommandText != "") er_cmd.ExecuteNonQuery();


        }


        public decimal exec_imp(string type_code, decimal stock_id, decimal stock_qty, DateTime in_date,
                              decimal? s_subacc_id, decimal? t_subacc_id, decimal keep_subacc_id, string move_comment,
                              string doc_comment, string outer_no, DateTime? out_date, DateTime? load_date, int source_id)


        {
            decimal oper_id = 0;
            if (IsOpened() == false) Open();
            SqlCommand imp_cmd = new SqlCommand();
            imp_cmd.Connection = _connection;
            imp_cmd.CommandType = CommandType.StoredProcedure;
            imp_cmd.CommandTimeout = _commandTimeout;
            if (type_code == "D_STOCK_OUT")
            {
                imp_cmd.CommandText = "bcs_oper_import_out";
                imp_cmd.Parameters.AddWithValue("@cl_depo_subacc_id", s_subacc_id);
            }
            else if (type_code == "D_STOCK_IN")
            {
                imp_cmd.CommandText = "bcs_oper_import_in";
                imp_cmd.Parameters.AddWithValue("@cl_depo_subacc_id", t_subacc_id);
            }
            else if (type_code == "STOCK_MOVE")
            {
                imp_cmd.CommandText = "bcs_oper_import_move";
                imp_cmd.Parameters.AddWithValue("@cl_depo_subacc_id", s_subacc_id);
                imp_cmd.Parameters.AddWithValue("@ca_depo_subacc_id", t_subacc_id);
            }
            else if (type_code == "STOCK_TRANSFER")
            {
                imp_cmd.CommandText = "bcs_oper_import_transfer";
                imp_cmd.Parameters.AddWithValue("@cl_depo_subacc_id", s_subacc_id);
                imp_cmd.Parameters.AddWithValue("@ca_depo_subacc_id", t_subacc_id);

            }

            imp_cmd.Parameters.AddWithValue("@stock_id", stock_id);
            imp_cmd.Parameters.AddWithValue("@in_date", in_date);
            imp_cmd.Parameters.AddWithValue("@kp_depo_subacc_id", keep_subacc_id);   //nullable
            imp_cmd.Parameters.AddWithValue("@stock_qty", stock_qty);
            imp_cmd.Parameters.AddWithValue("@doc_comment", doc_comment);
            //ComDepo.Parameters.AddWithValue("@document_no", null)
            //ComDepo.Parameters.AddWithValue("@found_remark", null)
            imp_cmd.Parameters.AddWithValue("@load_date", load_date);
            imp_cmd.Parameters.AddWithValue("@move_comment", move_comment);
            //ComDepo.Parameters.AddWithValue("@depocorr_oper_id", null)



            SqlParameter retval = new SqlParameter("@oper_id", SqlDbType.Decimal);
            retval.Direction = ParameterDirection.Output;
            imp_cmd.Parameters.Add(retval);

            imp_cmd.Parameters.AddWithValue("@outer_no", outer_no);
            imp_cmd.Parameters.AddWithValue("@outer_date", out_date);
            imp_cmd.Parameters.AddWithValue("@source_id", source_id);



            if (imp_cmd.CommandText != "")
            {
                imp_cmd.ExecuteNonQuery();

                oper_id = (decimal)imp_cmd.Parameters["@oper_id"].Value;
            }

            return oper_id;

        }

        public decimal? subacc_proc(string type_code, decimal export_id, decimal depo_acc_id, DateTime in_date, decimal act_subacc_id, string sMessage, decimal subacc_id)

        {
            if (IsOpened() == false) Open();
            decimal? oper_id = null;
            SqlCommand s_cmd = new SqlCommand();
            s_cmd.Connection = _connection;
            s_cmd.CommandType = CommandType.StoredProcedure;
            s_cmd.CommandTimeout = _commandTimeout;
            if (type_code == "create")
            {
                s_cmd.CommandText = "bcs_oper_import_create_subacc";
                //  s_cmd.Parameters.AddWithValue("@export_id", export_id);
                s_cmd.Parameters.AddWithValue("@cl_depo_acc_id", depo_acc_id);
                s_cmd.Parameters.AddWithValue("@kp_depo_subacc_id", act_subacc_id);
                s_cmd.Parameters.AddWithValue("@in_date", in_date);



                SqlParameter retval = new SqlParameter("@cl_depo_subacc_id", SqlDbType.Decimal);
                retval.Direction = ParameterDirection.Output;
                s_cmd.Parameters.Add(retval);

                if (s_cmd.CommandText != "")
                {
                    s_cmd.ExecuteNonQuery();

                    oper_id = (decimal?)s_cmd.Parameters["@cl_depo_subacc_id"].Value;


                }    ///output param

            }

            else
            {
                s_cmd.CommandText = "buf_prepare_movements_subacc_update";

                s_cmd.Parameters.AddWithValue("@export_id", export_id);

                s_cmd.Parameters.AddWithValue("@depo_acc_id", depo_acc_id);
                s_cmd.Parameters.AddWithValue("@act_subacc_id", act_subacc_id);
                s_cmd.Parameters.AddWithValue("@err_desc", sMessage);
                s_cmd.Parameters.AddWithValue("@subacc_id", subacc_id);
                if (s_cmd.CommandText != "") s_cmd.ExecuteNonQuery();
            }


            return oper_id;
        }





        public void exec_proc(string ProcString, int export_id)
        {
            if (IsOpened() == false) Open();
            SqlCommand ex_cmd = new SqlCommand();
            ex_cmd.Connection = _connection;
            ex_cmd.CommandType = CommandType.StoredProcedure;
            ex_cmd.CommandText = ProcString;
            ex_cmd.Parameters.AddWithValue("@export_id", export_id);
            ex_cmd.CommandTimeout = _commandTimeout;

            try
            {
                if (ex_cmd.CommandText != "") ex_cmd.ExecuteNonQuery();
            }

            finally
            {

            }
        }


        public void foundation_proc(decimal @id, DateTime? @in_date, decimal @doc_found_type_id, string @doc_number, string @doc_comment, int @need_update)
        {
            if (IsOpened() == false) Open();
            SqlCommand f_cmd = new SqlCommand();
            f_cmd.Connection = _connection;
            f_cmd.CommandType = CommandType.StoredProcedure;
            f_cmd.CommandTimeout = _commandTimeout;
            f_cmd.CommandText = "bcs_oper_import_found";
            f_cmd.Parameters.AddWithValue("@id", @id);
            f_cmd.Parameters.AddWithValue("@in_date", @in_date);
            f_cmd.Parameters.AddWithValue("@doc_found_type_id", @doc_found_type_id);
            f_cmd.Parameters.AddWithValue("@doc_number", @doc_number);
            f_cmd.Parameters.AddWithValue("@doc_comment", @doc_comment);
            f_cmd.Parameters.AddWithValue("@need_update", @need_update);


            if (f_cmd.CommandText != "") f_cmd.ExecuteNonQuery();

        }

        public string select_proc(int id)
        {
            if (IsOpened() == false) Open();
            SqlCommand sel_cmd = new SqlCommand();
            sel_cmd.Connection = _connection;
            sel_cmd.CommandTimeout = _commandTimeout;
            string oper = "";
            sel_cmd.CommandText = "select oper_name from bcs_bo_oper_status_list where id=" + id;

            try
            {
                if (sel_cmd.CommandText != "") { oper = sel_cmd.ExecuteScalar().ToString(); }

            }
            finally
            {

            }
            return oper;
        }


        public void upd_proc(string id, int Type_id, string smessage)
        {
            if (IsOpened() == false) Open();
            SqlCommand upd_cmd = new SqlCommand();
            upd_cmd.Connection = _connection;

            if (Type_id == 1)   //---error
                upd_cmd.CommandText = "update bcs_depo_tmp_movements set error = 1, err_desc =  @smessage where id = @id";
            else upd_cmd.CommandText = "update bcs_depo_tmp_movements set oper_id = @smessage, completed = 1 where id = @id";//ok
            upd_cmd.CommandTimeout = _commandTimeout;
            upd_cmd.Parameters.AddWithValue("@id", id);
            upd_cmd.Parameters.AddWithValue("@smessage", smessage);
            try
            {
                if (upd_cmd.CommandText != "") upd_cmd.ExecuteNonQuery();
            }
            finally
            {

            }
        }




    }
}
