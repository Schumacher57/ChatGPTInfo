﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.IO;
using System.Data.SqlClient;
using System.Xml;
using System.Xml.Linq;
using BCS.Aladdin.CredentialBroker.Client;

namespace ForeignStocksKval
{
    class Program
    {
        static void Main(string[] args)
        {
            // загрузить настроечный xml со значениями прокси --Dns.GetHostName()
            string app_path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            string inifilepath = System.IO.Path.Combine(app_path, "ini", "ForeignStocksKval.xml");
            string hostname = Dns.GetHostName().ToLower();
            string proxyName = "";
            string mailto = "";
            Dictionary<string, string> proxies = new Dictionary<string, string>();

            if (File.Exists(inifilepath))
            {
                XmlDocument XDocument = new XmlDocument();
                XDocument.Load(inifilepath);
                XmlElement xRoot = XDocument.DocumentElement;
                if (xRoot.Name == "Settings")
                {
                    foreach (XmlNode xnode in xRoot)
                    {
                        switch (xnode.Name)
                        {
                            case "proxies":
                                if (xnode.Attributes.Count == 2)
                                    if (xnode.Attributes.Item(0).Name.ToLower() == "server" && xnode.Attributes.Item(1).Name.ToLower() == "proxy")
                                        proxies.Add(xnode.Attributes.Item(0).Value.ToLower(), xnode.Attributes.Item(1).Value.ToLower());
                                break;
                            case "mailto":
                                mailto = xnode.InnerText;
                                break;
                        }

                    }
                }
                if (proxies.ContainsKey(hostname))
                    proxyName = proxies[hostname];

            };

            if (mailto.Trim().Length == 0)
                mailto = @"papetishev@bcs.ru,dobriyak@bcs.ru,BerdyuginaAI@bcs.ru,BannikovaAE@bcs.ru,TrusovaAI@bcs.ru,BadmaevaLA@bcs.ru";

            if (proxyName.Trim().Length == 0)
                proxyName = "http://s-nsk-pxsvc-03.global.bcs:8080";


            WebClient wc = new WebClient();
            wc.Encoding = Encoding.UTF8;
            //WebProxy proxy = new WebProxy("http://s-nsk-pxsvc-03.global.bcs:8080");
            WebProxy proxy = new WebProxy(proxyName);
            proxy.UseDefaultCredentials = true;
            wc.Proxy = proxy;
            string page;
            try
            {
                page = wc.DownloadString(@"http://www.cbr.ru/issuers_corporate/admission_financial_instruments/list_of_foreign_fin_inst/");
            }
            catch (Exception ex)
            {
                SmtpClient smtp = new SmtpClient("nsk-smtp.global.bcs");
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential("SVC-MB-aladdin", "4>Ym%5,M6w6kPn%F[UXwpu?qF.Q//yFwyhP2<P");
                smtp.Port = 25;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                
                string body = @"Ошибка в загрузке с сайта http://www.cbr.ru/issuers_corporate/admission_financial_instruments/list_of_foreign_fin_inst/";
                body = string.Format("{0}\n{1}", body, ex.Message);
                MailMessage mes = new MailMessage("aladdin@bcs.ru", mailto, @"Ошибка загрузки КВАЛ ИН", body);
                smtp.Send(mes);
                return;
            }
            
            MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(page));
            ms.Position = 0;
            StreamReader sr = new StreamReader(ms);
            //StockData sd;
            string str;
            List<StockData> l = new List<StockData>();
            /*
            while (!sr.EndOfStream) --запуск старого варианта
            {
                str = sr.ReadLine();
                if (str.Contains(@"<table"))
                {
                    FillStockList(sr, l);
                    break;
                }
            }
            */
            string xml_text = string.Empty;
            while (!sr.EndOfStream)
            {
                str = sr.ReadLine();
                if (str.Contains(@"<table"))
                {
                    str = str.Substring(str.IndexOf(@"<table"));
                    while (!str.Contains(@"</table>"))
                    {
                        xml_text = string.Format("{0}\n{1}", xml_text, str);
                        str = sr.ReadLine();
                    }
                    str = str.Substring(0, str.IndexOf("</table>") + 8);
                    xml_text = string.Format("{0}\n{1}", xml_text, str);
                    break;
                }   
            }
            sr.Close();
            try
            {
                FillStockListFromXML(xml_text, l);
            }
            catch (Exception ex)
            {
                SmtpClient smtp = new SmtpClient("nsk-smtp.global.bcs");
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential("SVC-MB-aladdin", "4>Ym%5,M6w6kPn%F[UXwpu?qF.Q//yFwyhP2<P");
                smtp.Port = 25;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                //string mailto = @"papetishev@bcs.ru,dobriyak@bcs.ru,BerdyuginaAI@bcs.ru,BannikovaAE@bcs.ru,TrusovaAI@bcs.ru,BadmaevaLA@bcs.ru";
                string body = @"Ошибка в загрузке с сайта http://www.cbr.ru/issuers_corporate/admission_financial_instruments/list_of_foreign_fin_inst/; не удалось распарсить таблицу";
                body = string.Format("{0}\n{1}", body, ex.Message);
                MailMessage mes = new MailMessage("aladdin@bcs.ru", mailto, @"Ошибка загрузки КВАЛ ИН", body);
                smtp.Send(mes);
                return;
            }
            SqlConnection con = new SqlConnection();
            SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
            sb.DataSource = @"(local)";
            sb.InitialCatalog = @"BCS_Depo";
            CredentialBrokerClientOptions brokerOptions = new CredentialBrokerClientOptions
            {
                BrokerUrl = "http://127.0.0.1:8731",
                TokenFilePath = @"D:\Apps\Protected\credential-broker.token",
                FallbackMode = FallbackMode.AnyFailureBySecretName
            };
            using (CredentialBrokerClient brokerClient = new CredentialBrokerClient(brokerOptions))
            {
                BrokerCredentials credentials = brokerClient.GetCredentialsAsync("Aladdin").GetAwaiter().GetResult();
                sb.UserID = credentials.User;
                sb.Password = credentials.Password;
            }

            con.ConnectionString = sb.ConnectionString;
            con.Open();
            
            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandType = System.Data.CommandType.StoredProcedure;
            com.CommandText = "sp_export_cbr_kval_as_stock";

            SqlParameter par;

            foreach (StockData stock in l)
            {
                com.Parameters.Clear();
                par = new SqlParameter();
                par.ParameterName = "@isin";
                par.Value = stock.isin;
                com.Parameters.Add(par);

                par = new SqlParameter();
                par.ParameterName = "@date";
                par.Value = stock.date;
                com.Parameters.Add(par);
                //Console.WriteLine("{0} {1}, {2}",com.CommandText, com.Parameters["@isin"].Value, com.Parameters["@date"].Value);
                com.ExecuteNonQuery();                
            }
            con.Close();

            if (l.Count == 0)
            {
                //SmtpClient smtp = new SmtpClient("mail.bcs.ru");
                SmtpClient smtp = new SmtpClient("nsk-smtp.global.bcs");
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential("SVC-MB-aladdin", "4>Ym%5,M6w6kPn%F[UXwpu?qF.Q//yFwyhP2<P");
                smtp.Port = 25;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                //string mailto = @"papetishev@bcs.ru,dobriyak@bcs.ru,BerdyuginaAI@bcs.ru,BannikovaAE@bcs.ru,TrusovaAI@bcs.ru,BadmaevaLA@bcs.ru";
                string body = @"Не найдены ЦБ для загрузки КВАЛ ИН на сайте http://www.cbr.ru/finmarket/issue/list_of_foreign_fin_inst/";
                MailMessage mes = new MailMessage("aladdin@bcs.ru", mailto, @"Не найдены ЦБ для загрузки КВАЛ ИН", body);
                smtp.Send(mes);
            }
        }

        static void FillStockList(StreamReader sr, List<StockData> l)
        {
            int counter = 0;
            string str = string.Empty;
            StockData sd;
            sd.isin = string.Empty;
            sd.date = string.Empty;

            str = sr.ReadLine();

            while (!str.Contains(@"</table>") && !sr.EndOfStream)
            {
                if (str == string.Empty)
                {
                    str = sr.ReadLine();
                    continue;
                }
                if (str.Contains(@"<tr>"))
                {
                    counter = 0;
                    str = sr.ReadLine();
                    while (!str.Contains(@"</tr>"))
                    {
                        if (str.Contains(@"<td"))
                        {
                            counter++;
                            if (counter == 2)
                            {
                                str = sr.ReadLine();
                                str = str.Replace(@"<p>", "");
                                str = str.Replace(@"</p>", "");
                                
                                //str = str.Substring(str.IndexOf(@">") + 1);
                                sd.isin = str;
                            }
                            if (counter == 4)
                            {
                                str = sr.ReadLine();
                                str = str.Replace(@"<p>", "");
                                str = str.Replace(@"</p>", "");
                                sd.date = str;
                                l.Add(sd);
                            }
                        }
                        str = sr.ReadLine();
                    }
                }
                str = sr.ReadLine();
            }
        }

        static void FillStockListFromXML(string sr, List<StockData> l)
        {
            string isin, date;
            sr = sr.Replace(@"&nbsp;", "");
           
            XElement x = XElement.Parse(sr.Replace("colspan=2", ""));
            if(x./*Element("table").*/Elements("tr").First().Elements("td").Count() != 5)
                x./*Element("table").*/Elements("tr").First().Remove();
            foreach (XElement e in x./*Element("table").*/Elements("tr"))
            {
                if (e.Elements("td").Count() != 0)
                {
                    isin = e.Elements("td").ElementAt(1).Value;
                    date = e.Elements("td").ElementAt(3).Value;
                    l.Add(new StockData() { isin = isin, date = date });
                }
            }
        }

        struct StockData
        {
            internal string isin;
            internal string date;
        }
    }
}
